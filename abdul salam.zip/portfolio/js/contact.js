document.querySelectorAll('.faq-question').forEach((question) => {
    question.addEventListener('click', () => {
        const icon = question.querySelector('.faq-icon');
        const answer = question.nextElementSibling;

        // Add animation class for smooth transition
        icon.classList.add('animate');

        setTimeout(() => {
            // Toggle "+" to "-" or vice versa after animation
            if (icon.textContent.trim() === "+") {
                icon.textContent = "-";
            } else {
                icon.textContent = "+";
            }

            // Remove animation class to allow for next interaction
            icon.classList.remove('animate');
        }, 300); // Animation duration (match with CSS transition time)

        // Show or hide answer
        answer.style.display = answer.style.display === 'block' ? 'none' : 'block';
    });
});


 // <-----Contact-box-start------>

 document.getElementById("submit-btn").addEventListener("click", function (event) {
    event.preventDefault(); // Prevent form from submitting and refreshing the page
  
    // Get the values from each input field
    const Name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;
    const button = document.getElementById("submit-btn");
  
    // Get email error message element
    const emailError = document.getElementById("email-error");
  
    // Validation for email containing "@"
    if (!email.includes("@")) {
      // Show error message if "@" is missing
      emailError.style.display = "block"; // Show the error message
      document.getElementById("email").classList.add("error"); // Add error styling to input field
      return; // Stop the function if validation fails
    } else {
      // Hide the error message if email is valid
      emailError.style.display = "none";
      document.getElementById("email").classList.remove("error");
    }
  
    // Log the values to the console (optional)
    console.log("Name:", Name);
    console.log("E-mail:", email);
    console.log("Phone:", phone);
    console.log("Subject:", subject);
    console.log("Message:", message);
  
    // Disable the button to prevent multiple submissions
    button.disabled = true;
  
    // Submit the form (simulate or actual submission logic)
    alert("Form submitted successfully!");
  });
  



  