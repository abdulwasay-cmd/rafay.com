
// <------header------>
window.addEventListener("scroll", () => {
    const header = document.getElementById("custom-header");
    if (window.scrollY > 50) {
      header.classList.add("scrolled");
    } else {
      header.classList.remove("scrolled");
    }
  });
  
   
   
   // <------scroll-buttom------>


// Select the up-icon button
const scrollToTopBtn = document.getElementById('scrollToTop');

// Function to handle scroll-to-top
scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0, // Scroll to the top
        behavior: 'smooth', // Smooth scrolling
    });
});

// Show button when scrolled down
window.addEventListener('scroll', () => {
    if (window.scrollY > 200) { // Show after 200px scroll
        scrollToTopBtn.classList.add('show');
    } else {
        scrollToTopBtn.classList.remove('show');
    }
});




// <------BlogButton------->

// Select the span element for Blog
const blogButton = document.querySelector('.button02');

// Add a click event listener
blogButton.addEventListener('click', function (event) {
    event.preventDefault(); // Prevent the default anchor behavior
    const targetSection = blogButton.getAttribute('data-target'); // Get the target section
   
    // Add your custom action here, e.g., scrolling to the section
    const section = document.querySelector(`#${targetSection}`);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
    } else {
        alert(`Section ${targetSection} not found!`);
    }
});




// <------Home Button------->

// Select the span element for Blog
const homeButton = document.querySelector('.button05');

// Add a click event listener
homeButton.addEventListener('click', function (event) {
    event.preventDefault(); // Prevent the default anchor behavior
    const targetSection = homeButton.getAttribute('data-target'); // Get the target section
   
    // Add your custom action here, e.g., scrolling to the section
    const section = document.querySelector(`#${targetSection}`);
    if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
    } else {
        alert(`Section ${targetSection} not found!`);
    }
});
     
// <----header-scroled----->
// Add event listener for scrolling
window.addEventListener('scroll', function () {
    const header = document.getElementById('-header');
    
    // Add 'scrolled' class when the page is scrolled
    if (window.scrollY > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
  });
       

   

      //  <-----button-project----->

      function openPage() {
        window.location.href = "project-button.html";
    }
     
     // <-----Contact-box-start------>

document.getElementById("myButton").addEventListener("click", function (event) {
    event.preventDefault(); // Prevent form from submitting and refreshing the page

    // Get the values from each input field
    const firstName = document.getElementById("firstName").value;
    const email = document.getElementById("email").value;
    const message = document.getElementById("message").value;
    const button = document.getElementById("myButton");

    // Validation for email containing "@"
    if (!email.includes("@")) {
        alert("Please enter a valid email address with '@'.");
        return; // Stop the function if validation fails
    }

    // Log the values to the console
    console.log("Name:", firstName);
    console.log("E-mail:", email);
    console.log("Message:", message);

    // Disable the button to prevent multiple submissions
    button.disabled = true;

    // Submit the form (simulate or actual submission logic)
    alert("Form submitted successfully!");
});


// <------Client-Message------>
// Select all slides
const slides = document.querySelectorAll('.testimonial-slide');
let currentSlide = 0;

// Function to show the next slide
function nextSlide() {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide + 1) % slides.length; // Loop back to the first slide
    slides[currentSlide].classList.add('active');
}

// Function to show the previous slide
function prevSlide() {
    slides[currentSlide].classList.remove('active');
    currentSlide = (currentSlide - 1 + slides.length) % slides.length; // Loop back to the last slide
    slides[currentSlide].classList.add('active');
}



