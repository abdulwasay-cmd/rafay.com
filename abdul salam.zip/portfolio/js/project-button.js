// <-----Contact-box-start------>

document.getElementById("myButton").addEventListener("click", function (event) {
  event.preventDefault(); // Prevent form from submitting and refreshing the page

  // Get the values from each input field
  const Name = document.getElementById("Name").value;
  const email = document.getElementById("E-mail").value;
  const phone = document.getElementById("phone").value;
  const Website = document.getElementById("Website").value;
  const Company = document.getElementById("Company").value;
  const service = document.getElementById("service").value;
  const message = document.getElementById("message").value;
  const button = document.getElementById("myButton");

  // Get email error message element
  const emailError = document.getElementById("email-error");
  
  // Validation for email containing "@" and not empty
  if (email.trim() === "") {
    // Show message if email is empty
    emailError.textContent = "Please fill in the Text.";
    emailError.style.display = "block"; // Show the error message
    document.getElementById("E-mail").classList.add("error"); // Add error styling to input field
    return; // Stop the function if validation fails
  } else if (!email.includes("@")) {
    // Show error message if "@" is missing
    emailError.textContent = "Please enter a valid email address with '@'.";
    emailError.style.display = "block"; // Show the error message
    document.getElementById("E-mail").classList.add("error"); // Add error styling to input field
    return; // Stop the function if validation fails
  } else {
    // Hide the error message if email is valid
    emailError.style.display = "none";
    document.getElementById("E-mail").classList.remove("error");
  }

  // Log the values to the console
  console.log("Name:", Name);
  console.log("E-mail:", email);
  console.log("Phone:", phone);
  console.log("Website:", Website);
  console.log("Company:", Company);
  console.log("Service:", service);
  console.log("Message:", message);
  
  // Disable the button to prevent multiple submissions
  button.disabled = true;

  // Submit the form (simulate or actual submission logic)
  alert("Form submitted successfully!");
});
